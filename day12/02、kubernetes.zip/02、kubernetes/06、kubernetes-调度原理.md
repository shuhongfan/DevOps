

<center>
<h1>
    Kubernetes 调度原理
    </h1>    
</center>



- Pod部分
  - 探针
  - 初始化容器
  - 临时容器
  - 污点、容忍
  - 调度原理

  - 配额限制 https://kubernetes.io/zh/docs/tasks/administer-cluster/quota-api-object/
  - 请求限制 https://kubernetes.io/zh/docs/tasks/administer-cluster/manage-resources/cpu-default-namespace/
  - （Kubernetes、Prometheus、ElasticSearch、Fluentd、Istio、JAEGER、Habor、Jenkins、）




