<center>
<h1>
    Kubernetes 安全性
    </h1>    
</center>



这里可以讲创建serviceaccount  用restapi操作k8s集群

